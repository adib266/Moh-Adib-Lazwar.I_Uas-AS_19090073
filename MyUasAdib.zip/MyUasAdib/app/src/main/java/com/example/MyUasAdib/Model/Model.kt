package com.example.MyUasAdib.Model

class Model (
    val handphone: List<Data>
) {
    data class Data (val nama:String?, val harga:String?)
}